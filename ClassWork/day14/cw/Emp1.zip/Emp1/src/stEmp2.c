#include <stdio.h>
#include <p1.h>

void disp1(const struct Employee emp)
{
    static int Employee_No=1;
    printf("\n===================\n");
    printf("\nEmployee %d details\n", Employee_No);
    printf("\nName: %s", emp.empname);
    printf("\nID: %d",emp.empid);
    Employee_No++; 
}