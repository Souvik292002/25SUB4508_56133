#include <stdio.h>
#include <p1.h>

int getDetails(struct Employee *emp1)
{
    printf("\nEnter EmpName and ID: ");
    scanf("%s%d",emp1->empname,&emp1->empid);
    return 0;
}