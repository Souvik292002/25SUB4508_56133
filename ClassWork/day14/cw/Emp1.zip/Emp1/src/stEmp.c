#include <stdio.h>
#include <p1.h>

void disp(const struct Employee emp)
{
    static int Employee_No=1;

    printf("\nEmployee %d details\n", Employee_No);
    printf("\nName: %s", emp.empname);
    printf("\nID: %d",emp.empid);
    Employee_No++; 
}