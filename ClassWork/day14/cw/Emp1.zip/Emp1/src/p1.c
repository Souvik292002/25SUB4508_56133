#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <p1.h>






int main()
{
   

    struct Employee emp1, emp2;
    

    getDetails(&emp1); //pass by address
    getDetails(&emp2);

    
    disp(emp1); //pass by value
    disp(emp2);
    
    disp1(emp1);
    printf("\n\n");

    return 0;

}

