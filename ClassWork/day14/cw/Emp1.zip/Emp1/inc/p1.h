#ifndef P1_H
#define P1_H

struct Employee
{
        int empid;
        char empname[20];
};

void disp(const struct Employee);
void disp1(const struct Employee);
int getDetails(struct Employee *);
#endif